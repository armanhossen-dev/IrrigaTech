/// FILE: lib/presentation/screens/dashboard_screen.dart
///
/// PLACEHOLDER — full implementation is PART 2.
/// Will show live SensorData + MotorState cards, pump toggles, and a
/// summary chart, sourced from sensorDataStreamProvider /
/// motorStateStreamProvider (see lib/domain/providers/repository_providers.dart).
library;

import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: Text('Dashboard')),
    );
  }
}
