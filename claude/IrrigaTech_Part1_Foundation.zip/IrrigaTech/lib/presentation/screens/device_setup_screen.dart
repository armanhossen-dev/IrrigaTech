/// FILE: lib/presentation/screens/device_setup_screen.dart
///
/// Lets the user paste their Blynk device auth token, test it against
/// the live repository, and persist it via flutter_secure_storage.
/// "Test Connection" temporarily switches repositoryModeProvider to
/// `live` with the pasted token so testConnection() exercises the real
/// BlynkRepository; it reverts to Demo mode on failure or cancel.
library;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants.dart';
import '../../core/router.dart';
import '../../core/utils/validators.dart';
import '../../domain/providers/repository_providers.dart';

enum _ConnectionTestState { idle, testing, success, failure }

class DeviceSetupScreen extends ConsumerStatefulWidget {
  const DeviceSetupScreen({super.key});

  @override
  ConsumerState<DeviceSetupScreen> createState() => _DeviceSetupScreenState();
}

class _DeviceSetupScreenState extends ConsumerState<DeviceSetupScreen> {
  final _tokenController = TextEditingController();
  final _secureStorage = const FlutterSecureStorage();
  _ConnectionTestState _state = _ConnectionTestState.idle;

  @override
  void initState() {
    super.initState();
    _loadSavedToken();
  }

  Future<void> _loadSavedToken() async {
    final savedToken =
        await _secureStorage.read(key: AppConstants.secureStorageBlynkTokenKey);
    if (savedToken != null && mounted) {
      _tokenController.text = savedToken;
    }
  }

  Future<void> _testConnection() async {
    final token = _tokenController.text.trim();

    if (!Validators.isPlausibleBlynkToken(token)) {
      setState(() => _state = _ConnectionTestState.failure);
      return;
    }

    setState(() => _state = _ConnectionTestState.testing);

    // Point providers at Live mode with this token so the real
    // BlynkRepository is exercised by testConnection().
    ref.read(blynkAuthTokenProvider.notifier).state = token;
    ref.read(repositoryModeProvider.notifier).state = RepositoryMode.live;

    final repository = ref.read(irrigationRepositoryProvider);
    final success = await repository.testConnection();

    if (!mounted) return;

    if (success) {
      await _secureStorage.write(
        key: AppConstants.secureStorageBlynkTokenKey,
        value: token,
      );
      setState(() => _state = _ConnectionTestState.success);
    } else {
      // Fall back to Demo mode so the rest of the app stays usable.
      ref.read(repositoryModeProvider.notifier).state = RepositoryMode.demo;
      setState(() => _state = _ConnectionTestState.failure);
    }
  }

  void _continueToDashboard() => context.go(AppRoutes.dashboard);

  void _skipForNow() {
    ref.read(repositoryModeProvider.notifier).state = RepositoryMode.demo;
    context.go(AppRoutes.dashboard);
  }

  @override
  void dispose() {
    _tokenController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Device Setup')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.developer_board_rounded,
                  size: 56, color: colorScheme.primary),
              const SizedBox(height: 20),
              Text(
                'Connect your hardware',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Paste the auth token from your Blynk "${AppConstants.blynkTemplateName}" '
                'device to connect this app to your ESP32-S3 irrigation system.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: colorScheme.onSurface.withOpacity(0.65),
                      height: 1.4,
                    ),
              ),
              const SizedBox(height: 28),
              TextField(
                controller: _tokenController,
                decoration: const InputDecoration(
                  labelText: 'Blynk Auth Token',
                  hintText: 'e.g. 8f3a1c...e92d',
                  prefixIcon: Icon(Icons.vpn_key_rounded),
                ),
                onChanged: (_) {
                  if (_state != _ConnectionTestState.idle) {
                    setState(() => _state = _ConnectionTestState.idle);
                  }
                },
              ),
              const SizedBox(height: 16),
              _ConnectionStatusBanner(state: _state),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _state == _ConnectionTestState.testing
                      ? null
                      : _testConnection,
                  icon: _state == _ConnectionTestState.testing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.wifi_tethering_rounded),
                  label: const Text('Test Connection'),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _state == _ConnectionTestState.success
                      ? _continueToDashboard
                      : null,
                  child: const Text('Continue'),
                ),
              ),
              const SizedBox(height: 12),
              Center(
                child: TextButton(
                  onPressed: _skipForNow,
                  child: const Text('Skip for now — use Demo mode'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ConnectionStatusBanner extends StatelessWidget {
  const _ConnectionStatusBanner({required this.state});

  final _ConnectionTestState state;

  @override
  Widget build(BuildContext context) {
    if (state == _ConnectionTestState.idle) return const SizedBox.shrink();

    final (icon, color, message) = switch (state) {
      _ConnectionTestState.testing => (
          Icons.hourglass_top_rounded,
          Colors.orange,
          'Testing connection…',
        ),
      _ConnectionTestState.success => (
          Icons.check_circle_rounded,
          Colors.green,
          'Connected! Your device is reachable.',
        ),
      _ConnectionTestState.failure => (
          Icons.error_rounded,
          Colors.red,
          'Could not connect. Check the token and try again.',
        ),
      _ConnectionTestState.idle => (Icons.info, Colors.grey, ''),
    };

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(message, style: TextStyle(color: color)),
          ),
        ],
      ),
    );
  }
}
