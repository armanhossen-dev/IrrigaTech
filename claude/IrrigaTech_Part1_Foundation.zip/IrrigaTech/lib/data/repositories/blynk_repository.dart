/// FILE: lib/data/repositories/blynk_repository.dart
///
/// Live implementation of IrrigationRepository backed by the real
/// ESP32-S3/Arduino Uno hardware via the Blynk Cloud REST API.
///
///   Read:  GET {baseUrl}/get?token={token}&{pin}
///   Write: GET {baseUrl}/update?token={token}&{pin}={value}
///
/// The auth token is intentionally left empty by default — it is supplied
/// at runtime (see DeviceSetupScreen) and persisted via
/// flutter_secure_storage, never hardcoded. This class currently polls on
/// a timer since the free Blynk REST API has no push/streaming endpoint;
/// PART 2 can swap this for Blynk's websocket API without changing the
/// IrrigationRepository interface.
library;

import 'dart:async';

import 'package:dio/dio.dart';

import '../models/sensor_data.dart';
import '../models/motor_state.dart';
import '../models/alert_log.dart';
import '../models/weather_forecast.dart';
import 'irrigation_repository.dart';
import '../../core/constants.dart';

class BlynkRepository implements IrrigationRepository {
  BlynkRepository({
    required this.authToken,
    Dio? dio,
    Duration pollInterval = const Duration(seconds: 5),
  })  : _dio = dio ?? Dio(),
        _pollInterval = pollInterval {
    _timer = Timer.periodic(_pollInterval, (_) => _poll());
  }

  /// Blynk device auth token. Configure via DeviceSetupScreen; left
  /// empty/placeholder until the user pastes their real token.
  String authToken;

  final Dio _dio;
  final Duration _pollInterval;
  late final Timer _timer;

  final _sensorController = StreamController<SensorData>.broadcast();
  final _motorController = StreamController<MotorState>.broadcast();

  Uri _getUri(String pin) => Uri.parse(
        '${AppConstants.blynkBaseUrl}/get?token=$authToken&$pin',
      );

  Uri _updateUri(String pin, String value) => Uri.parse(
        '${AppConstants.blynkBaseUrl}/update?token=$authToken&$pin=$value',
      );

  Future<double> _readPin(String pin) async {
    final response = await _dio.getUri(_getUri(pin));
    final data = response.data;
    if (data is num) return data.toDouble();
    if (data is String) return double.tryParse(data) ?? 0.0;
    if (data is List && data.isNotEmpty) {
      return double.tryParse(data.first.toString()) ?? 0.0;
    }
    return 0.0;
  }

  Future<void> _writePin(String pin, String value) async {
    await _dio.getUri(_updateUri(pin, value));
  }

  Future<void> _poll() async {
    if (authToken.isEmpty) return; // Not configured yet — no-op.
    try {
      final temperature = await _readPin(AppConstants.pinTemperature);
      final soilMoisture = await _readPin(AppConstants.pinSoilMoisture);
      final battery = await _readPin(AppConstants.pinBattery);
      final voltage = await _readPin(AppConstants.pinVoltage);

      _sensorController.add(SensorData(
        temperatureCelsius: temperature,
        soilMoisturePercent: soilMoisture,
        batteryPercent: battery,
        voltage: voltage,
        timestamp: DateTime.now(),
      ));

      final motor1 = await _readPin(AppConstants.pinMotor1FieldPump);
      final motor2 = await _readPin(AppConstants.pinMotor2TankPump);

      _motorController.add(MotorState(
        motor1FieldPumpOn: motor1 == 1,
        motor2TankPumpOn: motor2 == 1,
        lastUpdated: DateTime.now(),
      ));
    } catch (_) {
      // Network hiccups are expected on flaky field connections; PART 2
      // can surface these via a connectivity/alert provider. For now we
      // simply skip this tick and try again on the next poll.
    }
  }

  @override
  Stream<SensorData> get sensorDataStream => _sensorController.stream;

  @override
  Stream<MotorState> get motorStateStream => _motorController.stream;

  @override
  Future<void> setMotorState(MotorId motorId, bool isOn) async {
    final pin = motorId == MotorId.fieldPump
        ? AppConstants.pinMotor1FieldPump
        : AppConstants.pinMotor2TankPump;
    await _writePin(pin, isOn ? '1' : '0');
  }

  @override
  Future<bool> testConnection() async {
    if (authToken.isEmpty) return false;
    try {
      final response = await _dio.getUri(_getUri(AppConstants.pinTemperature));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<List<AlertLog>> getAlertLogs() async {
    // Live alert history will come from Firestore in PART 2/3. Returning
    // an empty list keeps this repository fully functional standalone.
    return [];
  }

  @override
  Future<WeatherForecast> getWeatherForecast() async {
    // OpenWeatherMap integration lands in a later part. Placeholder
    // forecast keeps the interface contract satisfied for now.
    return WeatherForecast(
      date: DateTime.now(),
      tempMinCelsius: 0,
      tempMaxCelsius: 0,
      condition: 'Unknown',
      description: 'Weather integration not yet configured',
      humidityPercent: 0,
      rainProbabilityPercent: 0,
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    _sensorController.close();
    _motorController.close();
  }
}
