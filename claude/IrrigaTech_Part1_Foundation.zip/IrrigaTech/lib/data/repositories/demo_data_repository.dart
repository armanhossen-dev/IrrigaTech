/// FILE: lib/data/repositories/demo_data_repository.dart
///
/// Fully offline implementation of IrrigationRepository. Streams
/// realistic, gently-drifting fake sensor values on a timer so the UI
/// (dashboard, charts, etc. built in PART 2/3) has something believable
/// to render without any hardware or network connection.
library;

import 'dart:async';
import 'dart:math';

import '../models/sensor_data.dart';
import '../models/motor_state.dart';
import '../models/alert_log.dart';
import '../models/weather_forecast.dart';
import 'irrigation_repository.dart';
import '../../core/constants.dart';

class DemoDataRepository implements IrrigationRepository {
  DemoDataRepository() {
    _seed();
    _timer = Timer.periodic(AppConstants.demoStreamInterval, (_) => _tick());
  }

  final _random = Random();
  late Timer _timer;

  final _sensorController = StreamController<SensorData>.broadcast();
  final _motorController = StreamController<MotorState>.broadcast();

  late SensorData _sensorData;
  late MotorState _motorState;

  void _seed() {
    _sensorData = SensorData(
      temperatureCelsius: 27.5,
      soilMoisturePercent: 42,
      batteryPercent: 88,
      voltage: 12.6,
      timestamp: DateTime.now(),
    );
    _motorState = MotorState(
      motor1FieldPumpOn: false,
      motor2TankPumpOn: false,
      lastUpdated: DateTime.now(),
    );
  }

  void _tick() {
    // Gently drift each value within a realistic band instead of pure
    // randomness, so charts in later parts look like a real sensor feed.
    final tempDrift = (_random.nextDouble() - 0.5) * 0.6;
    final moistureDrift = (_random.nextDouble() - 0.5) * 2.0;
    final batteryDrift = -_random.nextDouble() * 0.05;
    final voltageDrift = (_random.nextDouble() - 0.5) * 0.05;

    _sensorData = _sensorData.copyWith(
      temperatureCelsius:
          (_sensorData.temperatureCelsius + tempDrift).clamp(18.0, 40.0),
      soilMoisturePercent:
          (_sensorData.soilMoisturePercent + moistureDrift).clamp(5.0, 95.0),
      batteryPercent: (_sensorData.batteryPercent + batteryDrift).clamp(0.0, 100.0),
      voltage: (_sensorData.voltage + voltageDrift).clamp(10.5, 13.2),
      timestamp: DateTime.now(),
    );

    _sensorController.add(_sensorData);
  }

  @override
  Stream<SensorData> get sensorDataStream async* {
    yield _sensorData;
    yield* _sensorController.stream;
  }

  @override
  Stream<MotorState> get motorStateStream async* {
    yield _motorState;
    yield* _motorController.stream;
  }

  @override
  Future<void> setMotorState(MotorId motorId, bool isOn) async {
    // Simulate the small latency of a real network round-trip.
    await Future.delayed(const Duration(milliseconds: 300));
    _motorState = motorId == MotorId.fieldPump
        ? _motorState.copyWith(motor1FieldPumpOn: isOn, lastUpdated: DateTime.now())
        : _motorState.copyWith(motor2TankPumpOn: isOn, lastUpdated: DateTime.now());
    _motorController.add(_motorState);
  }

  @override
  Future<bool> testConnection() async {
    await Future.delayed(const Duration(milliseconds: 400));
    return true; // Demo mode always "connects".
  }

  @override
  Future<List<AlertLog>> getAlertLogs() async {
    return [
      AlertLog(
        id: 'demo-1',
        message: 'Soil moisture below threshold on Field A',
        severity: AlertSeverity.warning,
        timestamp: DateTime.now().subtract(const Duration(hours: 2)),
      ),
      AlertLog(
        id: 'demo-2',
        message: 'Field pump completed 15-minute cycle',
        severity: AlertSeverity.info,
        timestamp: DateTime.now().subtract(const Duration(hours: 5)),
        acknowledged: true,
      ),
    ];
  }

  @override
  Future<WeatherForecast> getWeatherForecast() async {
    return WeatherForecast(
      date: DateTime.now(),
      tempMinCelsius: 22,
      tempMaxCelsius: 33,
      condition: 'Clouds',
      description: 'scattered clouds',
      humidityPercent: 64,
      rainProbabilityPercent: 20,
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    _sensorController.close();
    _motorController.close();
  }
}
