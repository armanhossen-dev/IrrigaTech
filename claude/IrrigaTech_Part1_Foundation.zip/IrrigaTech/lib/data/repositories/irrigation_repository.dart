/// FILE: lib/data/repositories/irrigation_repository.dart
///
/// Contract every data source (Demo or live Blynk) must satisfy. Screens
/// and providers depend on this interface only — never on a concrete
/// implementation — so PART 2 can add e.g. a FirestoreRepository later
/// without touching UI code.
library;

import '../models/sensor_data.dart';
import '../models/motor_state.dart';
import '../models/alert_log.dart';
import '../models/weather_forecast.dart';

abstract class IrrigationRepository {
  /// Continuous stream of sensor readings (temperature, soil moisture,
  /// battery, voltage).
  Stream<SensorData> get sensorDataStream;

  /// Continuous stream of the two pumps' ON/OFF state.
  Stream<MotorState> get motorStateStream;

  /// Turns the given motor on/off. Implementations should optimistically
  /// or eventually emit the new state on [motorStateStream].
  Future<void> setMotorState(MotorId motorId, bool isOn);

  /// Verifies that this repository can actually reach its data source
  /// (e.g. a real HTTP round-trip to Blynk, or an instant success for
  /// Demo mode). Used by the Device Setup screen's "Test Connection".
  Future<bool> testConnection();

  /// Historical alert / security log entries.
  Future<List<AlertLog>> getAlertLogs();

  /// Latest weather forecast, used for irrigation-scheduling hints.
  Future<WeatherForecast> getWeatherForecast();

  /// Releases timers/streams/http clients. Call from provider disposal.
  void dispose();
}
