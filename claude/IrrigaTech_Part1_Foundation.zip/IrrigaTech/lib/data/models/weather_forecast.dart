/// FILE: lib/data/models/weather_forecast.dart
///
/// One day of forecast data, shaped to match OpenWeatherMap's daily
/// forecast fields. Used by Analytics/Dashboard in PART 2 for
/// irrigation-scheduling hints (e.g. skip watering if rain is likely).
library;

class WeatherForecast {
  final DateTime date;
  final double tempMinCelsius;
  final double tempMaxCelsius;
  final String condition; // e.g. "Clouds", "Rain", "Clear"
  final String description; // e.g. "light rain"
  final double humidityPercent;
  final double rainProbabilityPercent;

  const WeatherForecast({
    required this.date,
    required this.tempMinCelsius,
    required this.tempMaxCelsius,
    required this.condition,
    required this.description,
    required this.humidityPercent,
    required this.rainProbabilityPercent,
  });

  factory WeatherForecast.fromJson(Map<String, dynamic> json) {
    return WeatherForecast(
      date: json['date'] != null
          ? DateTime.parse(json['date'] as String)
          : DateTime.now(),
      tempMinCelsius: (json['tempMinCelsius'] as num?)?.toDouble() ?? 0.0,
      tempMaxCelsius: (json['tempMaxCelsius'] as num?)?.toDouble() ?? 0.0,
      condition: json['condition'] as String? ?? '',
      description: json['description'] as String? ?? '',
      humidityPercent: (json['humidityPercent'] as num?)?.toDouble() ?? 0.0,
      rainProbabilityPercent:
          (json['rainProbabilityPercent'] as num?)?.toDouble() ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() => {
        'date': date.toIso8601String(),
        'tempMinCelsius': tempMinCelsius,
        'tempMaxCelsius': tempMaxCelsius,
        'condition': condition,
        'description': description,
        'humidityPercent': humidityPercent,
        'rainProbabilityPercent': rainProbabilityPercent,
      };
}
