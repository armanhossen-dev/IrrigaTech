/// FILE: lib/data/models/sensor_data.dart
///
/// Snapshot of the hardware's live sensor readings.
/// Maps to Blynk virtual pins V0, V1, V4, V5.
library;

class SensorData {
  final double temperatureCelsius; // V0
  final double soilMoisturePercent; // V1
  final double batteryPercent; // V4
  final double voltage; // V5
  final DateTime timestamp;

  const SensorData({
    required this.temperatureCelsius,
    required this.soilMoisturePercent,
    required this.batteryPercent,
    required this.voltage,
    required this.timestamp,
  });

  factory SensorData.fromJson(Map<String, dynamic> json) {
    return SensorData(
      temperatureCelsius: (json['temperatureCelsius'] as num?)?.toDouble() ?? 0.0,
      soilMoisturePercent: (json['soilMoisturePercent'] as num?)?.toDouble() ?? 0.0,
      batteryPercent: (json['batteryPercent'] as num?)?.toDouble() ?? 0.0,
      voltage: (json['voltage'] as num?)?.toDouble() ?? 0.0,
      timestamp: json['timestamp'] != null
          ? DateTime.parse(json['timestamp'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'temperatureCelsius': temperatureCelsius,
        'soilMoisturePercent': soilMoisturePercent,
        'batteryPercent': batteryPercent,
        'voltage': voltage,
        'timestamp': timestamp.toIso8601String(),
      };

  SensorData copyWith({
    double? temperatureCelsius,
    double? soilMoisturePercent,
    double? batteryPercent,
    double? voltage,
    DateTime? timestamp,
  }) {
    return SensorData(
      temperatureCelsius: temperatureCelsius ?? this.temperatureCelsius,
      soilMoisturePercent: soilMoisturePercent ?? this.soilMoisturePercent,
      batteryPercent: batteryPercent ?? this.batteryPercent,
      voltage: voltage ?? this.voltage,
      timestamp: timestamp ?? this.timestamp,
    );
  }

  static SensorData empty() => SensorData(
        temperatureCelsius: 0,
        soilMoisturePercent: 0,
        batteryPercent: 0,
        voltage: 0,
        timestamp: DateTime.now(),
      );
}
