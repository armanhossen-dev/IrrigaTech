/// FILE: lib/data/models/motor_state.dart
///
/// ON/OFF state of the two pumps. Maps to Blynk virtual pins V2, V3.
library;

class MotorState {
  final bool motor1FieldPumpOn; // V2
  final bool motor2TankPumpOn; // V3
  final DateTime lastUpdated;

  const MotorState({
    required this.motor1FieldPumpOn,
    required this.motor2TankPumpOn,
    required this.lastUpdated,
  });

  factory MotorState.fromJson(Map<String, dynamic> json) {
    return MotorState(
      motor1FieldPumpOn: json['motor1FieldPumpOn'] as bool? ?? false,
      motor2TankPumpOn: json['motor2TankPumpOn'] as bool? ?? false,
      lastUpdated: json['lastUpdated'] != null
          ? DateTime.parse(json['lastUpdated'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'motor1FieldPumpOn': motor1FieldPumpOn,
        'motor2TankPumpOn': motor2TankPumpOn,
        'lastUpdated': lastUpdated.toIso8601String(),
      };

  MotorState copyWith({
    bool? motor1FieldPumpOn,
    bool? motor2TankPumpOn,
    DateTime? lastUpdated,
  }) {
    return MotorState(
      motor1FieldPumpOn: motor1FieldPumpOn ?? this.motor1FieldPumpOn,
      motor2TankPumpOn: motor2TankPumpOn ?? this.motor2TankPumpOn,
      lastUpdated: lastUpdated ?? this.lastUpdated,
    );
  }

  static MotorState empty() => MotorState(
        motor1FieldPumpOn: false,
        motor2TankPumpOn: false,
        lastUpdated: DateTime.now(),
      );
}

/// Identifies which motor a control action targets. Used by
/// IrrigationRepository.setMotorState so callers don't pass raw pin strings.
enum MotorId { fieldPump, tankPump }
