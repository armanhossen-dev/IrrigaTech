/// FILE: lib/data/models/alert_log.dart
///
/// A single alert / security-log entry (e.g. low battery, pump fault,
/// unauthorized access attempt). Consumed by the Alerts and Security Log
/// screens in PART 2 / PART 3.
library;

enum AlertSeverity { info, warning, critical }

class AlertLog {
  final String id;
  final String message;
  final AlertSeverity severity;
  final DateTime timestamp;
  final bool acknowledged;

  const AlertLog({
    required this.id,
    required this.message,
    required this.severity,
    required this.timestamp,
    this.acknowledged = false,
  });

  factory AlertLog.fromJson(Map<String, dynamic> json) {
    return AlertLog(
      id: json['id'] as String? ?? '',
      message: json['message'] as String? ?? '',
      severity: AlertSeverity.values.firstWhere(
        (e) => e.name == json['severity'],
        orElse: () => AlertSeverity.info,
      ),
      timestamp: json['timestamp'] != null
          ? DateTime.parse(json['timestamp'] as String)
          : DateTime.now(),
      acknowledged: json['acknowledged'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'message': message,
        'severity': severity.name,
        'timestamp': timestamp.toIso8601String(),
        'acknowledged': acknowledged,
      };

  AlertLog copyWith({
    String? id,
    String? message,
    AlertSeverity? severity,
    DateTime? timestamp,
    bool? acknowledged,
  }) {
    return AlertLog(
      id: id ?? this.id,
      message: message ?? this.message,
      severity: severity ?? this.severity,
      timestamp: timestamp ?? this.timestamp,
      acknowledged: acknowledged ?? this.acknowledged,
    );
  }
}
