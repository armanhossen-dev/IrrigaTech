/// FILE: lib/core/utils/formatters.dart
///
/// Display-formatting helpers used by dashboard/analytics screens in
/// PART 2 / PART 3. Kept minimal and dependency-free for now.
library;

class Formatters {
  Formatters._();

  static String temperature(double celsius) => '${celsius.toStringAsFixed(1)}°C';

  static String percent(double value) => '${value.toStringAsFixed(0)}%';

  static String voltage(double volts) => '${volts.toStringAsFixed(2)} V';

  static String timeAgo(DateTime timestamp) {
    final diff = DateTime.now().difference(timestamp);
    if (diff.inSeconds < 60) return '${diff.inSeconds}s ago';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
