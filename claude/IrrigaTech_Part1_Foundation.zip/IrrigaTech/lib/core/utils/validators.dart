/// FILE: lib/core/utils/validators.dart
///
/// Small, dependency-free helpers shared across screens.
library;

class Validators {
  Validators._();

  /// Blynk auth tokens are 32-char hex strings. This is a loose sanity
  /// check only — the real validation happens via testConnection().
  static bool isPlausibleBlynkToken(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return false;
    if (trimmed.length < 16) return false;
    final validChars = RegExp(r'^[a-zA-Z0-9_-]+$');
    return validChars.hasMatch(trimmed);
  }

  static bool isNotEmpty(String? value) => value != null && value.trim().isNotEmpty;
}
