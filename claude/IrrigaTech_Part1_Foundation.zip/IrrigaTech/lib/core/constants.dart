/// FILE: lib/core/constants.dart
///
/// App-wide constants: identity strings, Blynk hardware config, and
/// virtual-pin mapping. Keep this file as the single source of truth for
/// any value PART 2 / PART 3 need to reference (e.g. pin numbers).
library;

class AppConstants {
  AppConstants._();

  // ---- App identity ----
  static const String appName = 'IrrigaTech';
  static const String appTagline = 'Smart Irrigation. Effortless Farming.';

  // ---- Blynk hardware / cloud config ----
  static const String blynkTemplateId = 'TMPL6lSiWFFsO';
  static const String blynkTemplateName = 'Ecosense';

  /// Base host for the Blynk REST API. Auth token is supplied per-request,
  /// never hardcoded here.
  static const String blynkBaseUrl = 'https://blynk.cloud/external/api';

  // ---- Blynk virtual pin mapping ----
  // V0 = Temperature (°C)
  // V1 = Soil moisture (%)
  // V2 = Motor 1 — Field pump ON/OFF
  // V3 = Motor 2 — Tank pump ON/OFF
  // V4 = Battery (%)
  // V5 = Voltage (V)
  static const String pinTemperature = 'V0';
  static const String pinSoilMoisture = 'V1';
  static const String pinMotor1FieldPump = 'V2';
  static const String pinMotor2TankPump = 'V3';
  static const String pinBattery = 'V4';
  static const String pinVoltage = 'V5';

  // ---- Secure storage keys ----
  static const String secureStorageBlynkTokenKey = 'blynk_auth_token';

  // ---- Demo repository tuning ----
  static const Duration demoStreamInterval = Duration(seconds: 3);
}
