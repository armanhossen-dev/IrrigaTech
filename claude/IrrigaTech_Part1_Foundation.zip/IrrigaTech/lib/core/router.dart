/// FILE: lib/core/router.dart
///
/// Single source of truth for route paths/names. PART 2/3 should add new
/// routes here rather than constructing MaterialPageRoutes ad hoc, and
/// should reuse the AppRoutes constants below instead of hardcoding
/// path strings.
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../presentation/screens/splash_screen.dart';
import '../presentation/screens/onboarding_screen.dart';
import '../presentation/screens/login_screen.dart';
import '../presentation/screens/device_setup_screen.dart';
import '../presentation/screens/dashboard_screen.dart';
import '../presentation/screens/motor_detail_screen.dart';
import '../presentation/screens/analytics_screen.dart';
import '../presentation/screens/alerts_screen.dart';
import '../presentation/screens/security_log_screen.dart';
import '../presentation/screens/settings_screen.dart';

class AppRoutes {
  AppRoutes._();

  static const splash = '/splash';
  static const onboarding = '/onboarding';
  static const login = '/login';
  static const deviceSetup = '/device-setup';
  static const dashboard = '/dashboard';
  static const motorDetail = '/motor-detail';
  static const analytics = '/analytics';
  static const alerts = '/alerts';
  static const securityLog = '/security-log';
  static const settings = '/settings';
}

final goRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: AppRoutes.splash,
    routes: [
      GoRoute(
        path: AppRoutes.splash,
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: AppRoutes.onboarding,
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: AppRoutes.login,
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: AppRoutes.deviceSetup,
        builder: (context, state) => const DeviceSetupScreen(),
      ),
      GoRoute(
        path: AppRoutes.dashboard,
        builder: (context, state) => const DashboardScreen(),
      ),
      GoRoute(
        path: AppRoutes.motorDetail,
        builder: (context, state) => const MotorDetailScreen(),
      ),
      GoRoute(
        path: AppRoutes.analytics,
        builder: (context, state) => const AnalyticsScreen(),
      ),
      GoRoute(
        path: AppRoutes.alerts,
        builder: (context, state) => const AlertsScreen(),
      ),
      GoRoute(
        path: AppRoutes.securityLog,
        builder: (context, state) => const SecurityLogScreen(),
      ),
      GoRoute(
        path: AppRoutes.settings,
        builder: (context, state) => const SettingsScreen(),
      ),
    ],
  );
});
