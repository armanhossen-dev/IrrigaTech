/// FILE: lib/domain/providers/repository_providers.dart
///
/// Central place PART 2/3 should look for existing providers before
/// adding new ones. Everything here is keyed off `repositoryModeProvider`
/// so the whole app can flip between Demo and Live data with one toggle
/// (see DeviceSetupScreen / SettingsScreen in later parts).
library;

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/sensor_data.dart';
import '../../data/models/motor_state.dart';
import '../../data/repositories/irrigation_repository.dart';
import '../../data/repositories/demo_data_repository.dart';
import '../../data/repositories/blynk_repository.dart';
import '../../data/repositories/auth_repository.dart';

/// Which data source the app is currently using.
enum RepositoryMode { demo, live }

/// Toggle between Demo (offline, fake data) and Live (real Blynk
/// hardware) modes. Defaults to Demo so the app is fully usable without
/// any hardware or token configured.
final repositoryModeProvider = StateProvider<RepositoryMode>((ref) {
  return RepositoryMode.demo;
});

/// The Blynk auth token, set by DeviceSetupScreen after the user pastes
/// it and it's persisted to flutter_secure_storage. Kept in memory here
/// for quick access by BlynkRepository without re-reading secure storage
/// on every call.
final blynkAuthTokenProvider = StateProvider<String>((ref) => '');

/// Resolves to the concrete repository implementation matching the
/// current [repositoryModeProvider]. UI code should only ever depend on
/// this provider (typed as IrrigationRepository), never on
/// DemoDataRepository / BlynkRepository directly.
final irrigationRepositoryProvider = Provider<IrrigationRepository>((ref) {
  final mode = ref.watch(repositoryModeProvider);
  final token = ref.watch(blynkAuthTokenProvider);

  final IrrigationRepository repository = switch (mode) {
    RepositoryMode.demo => DemoDataRepository(),
    RepositoryMode.live => BlynkRepository(authToken: token),
  };

  ref.onDispose(repository.dispose);
  return repository;
});

/// Live stream of sensor readings from whichever repository is active.
final sensorDataStreamProvider = StreamProvider<SensorData>((ref) {
  final repository = ref.watch(irrigationRepositoryProvider);
  return repository.sensorDataStream;
});

/// Live stream of motor/pump state from whichever repository is active.
final motorStateStreamProvider = StreamProvider<MotorState>((ref) {
  final repository = ref.watch(irrigationRepositoryProvider);
  return repository.motorStateStream;
});

/// Singleton-per-app AuthRepository for Firebase Auth + Google Sign-In.
final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository();
});

/// Stream of the current Firebase user; null when signed out.
final authStateChangesProvider = StreamProvider((ref) {
  final authRepository = ref.watch(authRepositoryProvider);
  return authRepository.authStateChanges;
});
