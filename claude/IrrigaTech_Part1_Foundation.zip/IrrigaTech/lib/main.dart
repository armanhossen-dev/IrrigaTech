/// FILE: lib/main.dart
///
/// App entry point: initializes Firebase, wraps the app in ProviderScope,
/// and builds MaterialApp.router using the go_router config from
/// lib/core/router.dart and the Light/Dark themes from lib/core/theme.dart.
library;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';

import 'core/theme.dart';
import 'core/router.dart';
import 'core/constants.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Wrapped in try/catch so the app still boots in Demo mode before
  // `flutterfire configure` has been run (see lib/firebase_options.dart).
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint('Firebase not configured yet — continuing without it: $e');
  }

  runApp(const ProviderScope(child: IrrigaTechApp()));
}

class IrrigaTechApp extends ConsumerWidget {
  const IrrigaTechApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(goRouterProvider);

    return MaterialApp.router(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      routerConfig: router,
    );
  }
}
